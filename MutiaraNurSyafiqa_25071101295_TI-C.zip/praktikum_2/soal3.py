#Terdapat dua set yang berisi daftar keahlian (skill) dari dua tim pengembang:
tim_frontend = {"HTML", "CSS", "JavaScript", "React"}
tim_backend = {"Python", "JavaScript", "SQL",
"NodeJS"}
#Tentukan keahlian yang dimiliki oleh kedua tim (irisan).
#Tentukan keahlian yang hanya dimiliki oleh tim_backend.
#Gabungkan kedua set tersebut untuk melihat daftar total keahlian unik yang tersedia di perusahaan.