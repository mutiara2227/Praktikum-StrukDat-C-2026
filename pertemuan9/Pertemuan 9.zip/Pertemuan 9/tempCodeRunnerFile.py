
            # if current == self.head:
            #     break