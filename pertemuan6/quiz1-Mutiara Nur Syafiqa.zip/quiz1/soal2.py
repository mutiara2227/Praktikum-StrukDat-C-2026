stok_gadget = [
{'merk': 'Samsung', 'tipe': 'S23', 'harga': 12000000},
{'merk': 'Oppo', 'tipe': 'Reno 10', 'harga': 6000000},
{'merk': 'Xiaomi', 'tipe': 'Mi 13', 'harga': 10000000},
{'merk': 'Iphone', 'tipe': '15 Pro', 'harga': 20000000},
]

def filter_harga(data, min_harga,max_harga):
    for data in stok_gadget:
        if min_harga < data < max_harga:
            return []
        
        
batas_bawah = input(float('batas bawah = '))
batas_atas = input(float('batas atas = '))
hasil = filter_harga(stok_gadget['harga'], min_harga,max_harga)